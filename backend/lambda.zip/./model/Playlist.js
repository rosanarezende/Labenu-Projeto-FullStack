"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Playlist = void 0;
class Playlist {
    constructor(id, name, userId, collaborative) {
        this.id = id;
        this.name = name;
        this.userId = userId;
        this.collaborative = collaborative;
    }
    getId() {
        return this.id;
    }
    getUserId() {
        return this.userId;
    }
    getName() {
        return this.name;
    }
    getCollaborative() {
        return this.collaborative;
    }
}
exports.Playlist = Playlist;
