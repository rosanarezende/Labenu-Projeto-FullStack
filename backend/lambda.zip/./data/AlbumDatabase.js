"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumDatabase = void 0;
const BaseDatabase_1 = require("./BaseDatabase");
const Album_1 = require("../model/Album");
class AlbumDatabase extends BaseDatabase_1.BaseDatabase {
    toModel(dbModel) {
        return dbModel && new Album_1.Album(dbModel.id, dbModel.band_id, dbModel.name);
    }
    createAlbum(album) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.connection.call(this)
                .insert({
                id: album.getId(),
                band_id: album.getBandId(),
                name: album.getName()
            })
                .into(AlbumDatabase.TABLE_NAME);
        });
    }
    getAlbumById(id) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this)
                .select("*")
                .from(AlbumDatabase.TABLE_NAME)
                .where({ id });
            return this.toModel(result[0]);
        });
    }
    relateGenreAlbum(albumId, genreList) {
        return __awaiter(this, void 0, void 0, function* () {
            for (const genre of genreList) {
                yield this.connection()
                    .insert({
                    album_id: albumId,
                    genre_id: genre
                })
                    .into(AlbumDatabase.TABLE_RELATION);
            }
        });
    }
    getAlbunsByBandId(bandId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT * 
            FROM ${AlbumDatabase.TABLE_NAME}
            WHERE band_id = "${bandId}"
        `);
            return result[0].map((res) => this.toModel(res));
        });
    }
    // public async getAllAlbuns(): Promise<Album[]> {
    //     const result = await super.connection().raw(`
    //         SELECT * 
    //         FROM ${AlbumDatabase.TABLE_NAME}
    //     `)
    //     return result[0].map((res: any) => this.toModel(res))
    // }
    deleteAlbum(albumId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT 
                m.id as music_id,
                m.album_id
            FROM SpotenuPlaylist p
            JOIN SpotenuPlaylistToMusic pm ON p.id = pm.playlist_id
            JOIN SpotenuMusic m ON pm.music_id = m.id
            JOIN SpotenuAlbum a ON m.album_id = a.id
            WHERE a.id = "${albumId}";
        `);
            for (let item of result[0]) {
                yield _super.connection.call(this).raw(`
                DELETE from SpotenuPlaylistToMusic
                WHERE music_id = "${item === null || item === void 0 ? void 0 : item.music_id}"
            `);
            }
            yield _super.connection.call(this).raw(`
            DELETE from SpotenuMusic
            WHERE album_id = "${albumId}"
        `);
            yield _super.connection.call(this).raw(`
            DELETE from SpotenuGenreToAlbum
            WHERE album_id = "${albumId}"
        `);
            yield _super.connection.call(this).raw(`
            DELETE from ${AlbumDatabase.TABLE_NAME}
            WHERE id = "${albumId}"
        `);
        });
    }
    getBandByAlbumId(albumId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT * 
            FROM SpotenuAlbum
            WHERE id = "${albumId}"
        `);
            return this.toModel(result[0]);
        });
    }
    editAlbumName(albumId, albumName) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.connection.call(this).raw(`
            UPDATE SpotenuAlbum
            SET name = "${albumName}"
            WHERE id = "${albumId}";
        `);
        });
    }
}
exports.AlbumDatabase = AlbumDatabase;
AlbumDatabase.TABLE_NAME = "SpotenuAlbum";
AlbumDatabase.TABLE_RELATION = "SpotenuGenreToAlbum";
