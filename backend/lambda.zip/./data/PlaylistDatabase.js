"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlaylistDatabase = void 0;
const BaseDatabase_1 = require("./BaseDatabase");
const Playlist_1 = require("../model/Playlist");
class PlaylistDatabase extends BaseDatabase_1.BaseDatabase {
    toModel(dbModel) {
        return dbModel &&
            new Playlist_1.Playlist(dbModel.id, dbModel.name, dbModel.user_id, dbModel.collaborative);
    }
    createPlaylist(playlist) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection },
            convertBooleanToTinyint: { get: () => super.convertBooleanToTinyint }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.connection.call(this)
                .insert({
                id: playlist.getId(),
                name: playlist.getName(),
                user_id: playlist.getUserId(),
                collaborative: _super.convertBooleanToTinyint.call(this, false)
            })
                .into(PlaylistDatabase.TABLE_NAME);
        });
    }
    relatePlaylistMusic(playlistId, musicList) {
        return __awaiter(this, void 0, void 0, function* () {
            for (const music of musicList) {
                yield this.connection()
                    .insert({
                    playlist_id: playlistId,
                    music_id: music
                })
                    .into(PlaylistDatabase.TABLE_RELATION);
            }
        });
    }
    relateOneMusicToPlaylist(playlistId, musicId) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.connection()
                .insert({
                playlist_id: playlistId,
                music_id: musicId
            })
                .into(PlaylistDatabase.TABLE_RELATION);
        });
    }
    makeCollaborative(playlistId, option) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.connection.call(this).raw(`
            UPDATE ${PlaylistDatabase.TABLE_NAME}
            SET collaborative = ${option} 
            WHERE id = "${playlistId}"
        `);
        });
    }
    // public async getPlaylistsByUserId(userId: string): Promise<Playlist[]> {
    //     const result = await super.connection().raw(`
    //         SELECT * 
    //         FROM ${PlaylistDatabase.TABLE_NAME}
    //         WHERE user_id = "${userId}"
    //         ORDER BY name
    //     `)
    //     //  LIMIT 10 offset ${offset}
    //     return result[0].map((res: any) => this.toModel(res))
    // }
    getPlaylistsByUserId(userId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT * 
            FROM ${PlaylistDatabase.TABLE_NAME}
            WHERE user_id = "${userId}"
            ORDER BY name
        `);
            return result[0].map((res) => this.toModel(res));
        });
    }
    getPlaylistById(id) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this)
                .select("*")
                .from(PlaylistDatabase.TABLE_NAME)
                .where({ id });
            return this.toModel(result[0]);
        });
    }
    getPlaylistDetail(playlistId, offset) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT 
                p.name,
                p.id,
                p.user_id,
                p.collaborative,
                m.name as music_name,
                m.id as music_id,
                a.name as album_name,
                m.album_id
            FROM SpotenuPlaylist p
            JOIN SpotenuPlaylistToMusic pm ON p.id = pm.playlist_id
            JOIN SpotenuMusic m ON pm.music_id = m.id
            JOIN SpotenuAlbum a ON m.album_id = a.id
            WHERE p.id = "${playlistId}"
            ORDER BY m.name
            LIMIT 10 offset ${offset}
        `);
            return result[0];
        });
    }
    countPlaylistDetail(playlistId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT COUNT(pm.music_id) as count
            FROM SpotenuPlaylistToMusic pm
            WHERE playlist_id = "${playlistId}";
        `);
            return result[0][0];
        });
    }
    findMusicInPlaylist(musicId, playlistId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT * 
            FROM ${PlaylistDatabase.TABLE_RELATION}
            WHERE music_id = "${musicId}" 
            AND playlist_id = "${playlistId}";
        `);
            return result[0];
        });
    }
    removeMusicFromPlaylist(musicId, playlistId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.connection.call(this).raw(`
            DELETE FROM ${PlaylistDatabase.TABLE_RELATION}
            WHERE music_id = "${musicId}" 
            AND playlist_id = "${playlistId}";
        `);
        });
    }
    deletePlaylist(playlistId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.connection.call(this).raw(`
            DELETE FROM ${PlaylistDatabase.TABLE_RELATION}
            WHERE playlist_id = "${playlistId}";
        `);
            yield _super.connection.call(this).raw(`
            DELETE FROM ${PlaylistDatabase.TABLE_NAME}
            WHERE id = "${playlistId}";
        `);
        });
    }
    editPlaylistName(playlistId, playlistName) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.connection.call(this).raw(`
            UPDATE ${PlaylistDatabase.TABLE_NAME}
            SET name = "${playlistName}"
            WHERE id = "${playlistId}";
        `);
        });
    }
}
exports.PlaylistDatabase = PlaylistDatabase;
PlaylistDatabase.TABLE_NAME = "SpotenuPlaylist";
PlaylistDatabase.TABLE_RELATION = "SpotenuPlaylistToMusic";
