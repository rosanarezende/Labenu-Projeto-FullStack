"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MusicDatabase = void 0;
const BaseDatabase_1 = require("./BaseDatabase");
const Music_1 = require("../model/Music");
class MusicDatabase extends BaseDatabase_1.BaseDatabase {
    toModel(dbModel) {
        return dbModel && new Music_1.Music(dbModel.id, dbModel.name, dbModel.album_id);
    }
    createMusic(music) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.connection.call(this)
                .insert({
                id: music.getId(),
                name: music.getName(),
                album_id: music.getAlbumId()
            })
                .into(MusicDatabase.TABLE_NAME);
        });
    }
    getMusicsByAlbumId(albumId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT *
            FROM ${MusicDatabase.TABLE_NAME}
            WHERE album_id = "${albumId}"
        `);
            return result[0].map((res) => this.toModel(res));
        });
    }
    getAllMusicsDetailed() {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT 
                m.name as music_name,
                m.id as music_id,
                a.name as album_name,
                m.album_id,
                u.name as band_name,
                u.id as band_id,
                u.description as band_description,
                g.name as genre_name,
                g.id as genre_id
            FROM SpotenuMusic m
            JOIN SpotenuAlbum a ON m.album_id = a.id
            JOIN SpotenuUser u ON a.band_id = u.id
            JOIN SpotenuGenreToAlbum ga ON a.id = ga.album_id
            JOIN SpotenuGenre g ON ga.genre_id = g.id
            ORDER BY m.name ASC
        `);
            let resultFormatted = [];
            for (let music of result[0]) {
                const musicInArr = resultFormatted.find((item) => item.music_id === music.music_id);
                if (!musicInArr) {
                    let music2 = Object.assign(Object.assign({}, music), { genres: [{
                                name: music.genre_name,
                                id: music.genre_id
                            }] });
                    resultFormatted.push(music2);
                }
                else {
                    musicInArr.genres.push({
                        name: music.genre_name,
                        id: music.genre_id
                    });
                }
            }
            return resultFormatted;
        });
    }
    getMusicsByGenre(genreId, offset) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT 
                m.name as music_name,
                m.id as music_id,
                a.name as album_name,
                m.album_id,
                u.name as band_name,
                u.id as band_id,
                u.description as band_description,
                g.name as genre_name,
                g.id as genre_id
            FROM SpotenuMusic m
            JOIN SpotenuAlbum a ON m.album_id = a.id
            JOIN SpotenuUser u ON a.band_id = u.id
            JOIN SpotenuGenreToAlbum ga ON a.id = ga.album_id
            JOIN SpotenuGenre g ON ga.genre_id = g.id
            WHERE g.id = "${genreId}"
            ORDER BY m.name ASC
            LIMIT 10 offset ${offset}
        `);
            return result[0];
        });
    }
    getMusicsList(offset) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this)
                .select('*')
                .from(MusicDatabase.TABLE_NAME)
                .orderBy("name", "asc")
                .limit(10)
                .offset(offset);
            return result;
        });
    }
    countMusicsByGenre(genreId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT COUNT(m.id) as count
            FROM SpotenuMusic m
            JOIN SpotenuAlbum a ON m.album_id = a.id
            JOIN SpotenuUser u ON a.band_id = u.id
            JOIN SpotenuGenreToAlbum ga ON a.id = ga.album_id
            JOIN SpotenuGenre g ON ga.genre_id = g.id
            WHERE g.id = "${genreId}"
        `);
            return result[0][0];
        });
    }
    countMusicsList() {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT COUNT(m.id) as count
            FROM SpotenuMusic m;
        `);
            return result[0][0];
        });
    }
    getMyMusics(bandId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT 
                m.name as music_name,
                m.id as music_id,
                a.name as album_name,
                m.album_id,
                u.name as band_name,
                a.band_id
            FROM SpotenuMusic m
            JOIN SpotenuAlbum a ON m.album_id = a.id
            JOIN SpotenuUser u ON a.band_id = u.id
            WHERE a.band_id = "${bandId}"
        `);
            return result[0];
        });
    }
    deleteMusic(id) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.connection.call(this).raw(`
            DELETE from SpotenuPlaylistToMusic
            WHERE music_id = "${id}"
        `);
            yield _super.connection.call(this).raw(`
            DELETE from SpotenuMusic
            WHERE id = "${id}"
        `);
        });
    }
    getMusicById(id) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.connection.call(this).raw(`
            SELECT *
            FROM ${MusicDatabase.TABLE_NAME}
            WHERE id = "${id}"
        `);
            return this.toModel(result[0][0]);
        });
    }
    editMusicName(musicId, musicName) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.connection.call(this).raw(`
            UPDATE SpotenuMusic
            SET name = "${musicName}"
            WHERE id = "${musicId}";
        `);
        });
    }
    editAlbumToMusic(musicId, albumId) {
        const _super = Object.create(null, {
            connection: { get: () => super.connection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.connection.call(this).raw(`
            UPDATE SpotenuMusic
            SET album_id = "${albumId}"
            WHERE id = "${musicId}";
        `);
        });
    }
}
exports.MusicDatabase = MusicDatabase;
MusicDatabase.TABLE_NAME = "SpotenuMusic";
