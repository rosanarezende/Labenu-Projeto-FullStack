"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.playlistRouter = void 0;
const express_1 = __importDefault(require("express"));
const PlaylistController_1 = require("../controller/PlaylistController");
exports.playlistRouter = express_1.default.Router();
const playlistController = new PlaylistController_1.PlaylistController();
exports.playlistRouter.get("/my", playlistController.getPlaylistsByUserId);
exports.playlistRouter.get("/detail/:id/:page", playlistController.getPlaylistDetail);
exports.playlistRouter.get("/count/:id", playlistController.countPlaylistDetail);
exports.playlistRouter.post("/create", playlistController.createPlaylist);
exports.playlistRouter.post("/add-music", playlistController.addMusicToPlaylist);
exports.playlistRouter.post("/collaborative", playlistController.makeCollaborative);
exports.playlistRouter.post("/edit-name", playlistController.editPlaylistName);
exports.playlistRouter.delete("/remove-music", playlistController.removeMusicFromPlaylist);
exports.playlistRouter.delete("/delete/:id", playlistController.deletePlaylist);
