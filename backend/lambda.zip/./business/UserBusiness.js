"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserBusiness = void 0;
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
const User_1 = require("../model/User");
const NotFoundError_1 = require("../errors/NotFoundError");
const UnauthorizedError_1 = require("../errors/UnauthorizedError");
const GenericError_1 = require("../errors/GenericError");
class UserBusiness {
    constructor(userDatabase, hashManager, authenticator, idGenerator) {
        this.userDatabase = userDatabase;
        this.hashManager = hashManager;
        this.authenticator = authenticator;
        this.idGenerator = idGenerator;
    }
    signupListeningUser(name, email, nickname, password, role) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!name || !email || !nickname || !password || !role) {
                throw new InvalidParameterError_1.InvalidParameterError("Preencha os campos para prosseguir.");
            }
            if (email.indexOf("@") === -1) {
                throw new InvalidParameterError_1.InvalidParameterError("Email inválido");
            }
            if (password.length < 6) {
                throw new InvalidParameterError_1.InvalidParameterError("Senha inválida");
            }
            const id = this.idGenerator.generatorId();
            const cryptedPassword = yield this.hashManager.hash(password);
            const user = new User_1.User(id, name, email, nickname, cryptedPassword, User_1.stringToUserRole(role));
            yield this.userDatabase.createListeningOrAdmnistrationUser(user);
            const accessToken = this.authenticator.generateToken({ id, role });
            return { accessToken, role: user.getRole(), name: user.getName() };
        });
    }
    signupAdministratorUser(name, email, nickname, password, token) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!name || !email || !nickname || !password || !token) {
                throw new InvalidParameterError_1.InvalidParameterError("Preencha os campos para prosseguir.");
            }
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.ADMINISTRATOR) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para cadastrar um usuário administrador!");
            }
            if (email.indexOf("@") === -1) {
                throw new InvalidParameterError_1.InvalidParameterError("Email inválido");
            }
            if (password.length < 10) {
                throw new InvalidParameterError_1.InvalidParameterError("Senha inválida");
            }
            const role = User_1.UserRole.ADMINISTRATOR;
            const id = this.idGenerator.generatorId();
            const cryptedPassword = yield this.hashManager.hash(password);
            const newUser = new User_1.User(id, name, email, nickname, cryptedPassword, User_1.stringToUserRole(role));
            yield this.userDatabase.createListeningOrAdmnistrationUser(newUser);
            this.authenticator.generateToken({ id, role });
        });
    }
    signupBandUser(name, email, nickname, password, description) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!name || !email || !nickname || !password || !description) {
                throw new InvalidParameterError_1.InvalidParameterError("Preencha os campos para prosseguir.");
            }
            if (email.indexOf("@") === -1) {
                throw new InvalidParameterError_1.InvalidParameterError("Email inválido");
            }
            if (password.length < 6) {
                throw new InvalidParameterError_1.InvalidParameterError("Senha inválida");
            }
            const id = this.idGenerator.generatorId();
            const role = User_1.UserRole.BAND;
            const cryptedPassword = yield this.hashManager.hash(password);
            const user = new User_1.User(id, name, email, nickname, cryptedPassword, User_1.stringToUserRole(role), description);
            yield this.userDatabase.createBandUser(user);
        });
    }
    login(input, password) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!input || !password) {
                throw new InvalidParameterError_1.InvalidParameterError("Preencha os campos para prosseguir.");
            }
            let user;
            if (input.indexOf("@") !== -1) {
                user = yield this.userDatabase.getUserByEmail(input);
            }
            else {
                user = yield this.userDatabase.getUserByNickname(input);
            }
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário e/ou senha inválidos.");
            }
            if (user.getIsApproved() === false) {
                throw new UnauthorizedError_1.UnauthorizedError("A banda precisa ser aprovada por um administrador para realizar login.");
            }
            const isPasswordCorrect = yield this.hashManager.compare(password, user.getPassword());
            if (!isPasswordCorrect) {
                throw new InvalidParameterError_1.InvalidParameterError("Usuário e/ou senha inválidos");
            }
            const accessToken = this.authenticator.generateToken({
                id: user.getId(),
                role: user.getRole(),
            });
            return { accessToken, role: user.getRole(), name: user.getName() };
        });
    }
    getAllBands(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.ADMINISTRATOR) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão visualizar todos os artistas!");
            }
            const bands = yield this.userDatabase.getAllBands();
            return bands.map(band => ({
                id: band.getId(),
                name: band.getName(),
                email: band.getEmail(),
                nickname: band.getNickame(),
                isApproved: band.getIsApproved() == true ? true : false
            }));
        });
    }
    aproveBand(id, token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.ADMINISTRATOR) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para aprovar artista!");
            }
            const band = yield this.userDatabase.getUserById(id);
            if (!band) {
                throw new NotFoundError_1.NotFoundError("Artista não encontrado.");
            }
            if (band.getIsApproved() == true) {
                throw new GenericError_1.GenericError("Artista já aprovado anteriormente.");
            }
            yield this.userDatabase.approveBand(id);
        });
    }
    getAllUsers(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.ADMINISTRATOR) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão visualizar todos os usuários!");
            }
            const users = yield this.userDatabase.getAllUsers();
            return users.map(user => ({
                id: user.getId(),
                name: user.getName(),
                email: user.getEmail(),
                nickname: user.getNickame(),
                isApproved: user.getIsApproved() == true ? true : false,
                role: user.getRole()
            }));
        });
    }
    blockUser(id, token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.authenticator.verify(token);
            const userLogged = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!userLogged) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (userLogged.getRole() !== User_1.UserRole.ADMINISTRATOR) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para bloquear usuário!");
            }
            const user = yield this.userDatabase.getUserById(id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado.");
            }
            if (user.getRole() === User_1.UserRole.ADMINISTRATOR) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para bloquear um administrador!");
            }
            if (user.getIsApproved() == false) {
                throw new GenericError_1.GenericError("Este usuário já estava bloqueado.");
            }
            yield this.userDatabase.blockUser(id);
        });
    }
    getProfile(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.authenticator.verify(token);
            const userLogged = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!userLogged) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            return {
                id: userLogged.getId(),
                name: userLogged.getName(),
                nickname: userLogged.getNickame(),
                email: userLogged.getEmail(),
                description: userLogged.getDescription(),
                role: userLogged.getRole(),
                isApproved: userLogged.getIsApproved()
            };
            return userLogged;
        });
    }
    changeNameById(name, token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.authenticator.verify(token);
            const userLogged = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!userLogged) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            yield this.userDatabase.changeNameById(userLogged.getId(), name);
        });
    }
    makePremium(id, token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.authenticator.verify(token);
            const userLogged = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!userLogged) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (userLogged.getRole() !== User_1.UserRole.ADMINISTRATOR) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para tornar o usuário premium!");
            }
            const user = yield this.userDatabase.getUserById(id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado.");
            }
            if (user.getRole() === User_1.UserRole.ADMINISTRATOR || user.getRole() === User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Apenas ouvintes podem ser transformados em premium!");
            }
            if (user.getRole() === User_1.UserRole.PAYINGLISTENER) {
                throw new GenericError_1.GenericError("Este usuário já é PREMIUM.");
            }
            yield this.userDatabase.makePremium(id);
        });
    }
}
exports.UserBusiness = UserBusiness;
