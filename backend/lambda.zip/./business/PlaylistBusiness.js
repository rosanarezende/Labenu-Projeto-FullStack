"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlaylistBusiness = void 0;
const NotFoundError_1 = require("../errors/NotFoundError");
const UnauthorizedError_1 = require("../errors/UnauthorizedError");
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
const User_1 = require("../model/User");
const Playlist_1 = require("../model/Playlist");
const GenericError_1 = require("../errors/GenericError");
class PlaylistBusiness {
    constructor(playlistDatabase, userDatabase, musicDatabase, idGenerator, authenticator) {
        this.playlistDatabase = playlistDatabase;
        this.userDatabase = userDatabase;
        this.musicDatabase = musicDatabase;
        this.idGenerator = idGenerator;
        this.authenticator = authenticator;
    }
    createPlaylist(token, name) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!name || !token) {
                throw new InvalidParameterError_1.InvalidParameterError("Preencha os campos para prosseguir.");
            }
            const userLoggedData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.PAYINGLISTENER) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para cadastrar uma playlist!");
            }
            const id = this.idGenerator.generatorId();
            const userId = user.getId();
            const newPlaylist = new Playlist_1.Playlist(id, name, userId);
            yield this.playlistDatabase.createPlaylist(newPlaylist);
        });
    }
    getPlaylistsByUserId(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.PAYINGLISTENER) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para visualizar essas playlists!");
            }
            const userId = user.getId();
            const playlists = yield this.playlistDatabase.getPlaylistsByUserId(userId);
            return playlists;
        });
    }
    addMusicToPlaylist(token, musicId, playlistId) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() === User_1.UserRole.ADMINISTRATOR || user.getRole() === User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para adicionar música na playlist!");
            }
            const music = yield this.musicDatabase.getMusicById(musicId);
            if (!music) {
                throw new NotFoundError_1.NotFoundError("Música não encontrada!");
            }
            const playlist = yield this.playlistDatabase.getPlaylistById(playlistId);
            if (!playlist) {
                throw new NotFoundError_1.NotFoundError("Playlist não encontrada!");
            }
            if (playlist.getCollaborative() === false) {
                const usserLoggedPlaylists = yield this.playlistDatabase.getPlaylistsByUserId(user.getId());
                let found = usserLoggedPlaylists.find(playlist => playlist.getId() === playlistId);
                if (!found) {
                    throw new NotFoundError_1.NotFoundError("Você não tem permissão para adicionar música nessa playlist!");
                }
            }
            const findMusicInPlaylist = yield this.playlistDatabase.findMusicInPlaylist(musicId, playlistId);
            if (findMusicInPlaylist.length !== 0) {
                throw new GenericError_1.GenericError("Essa música já foi adicionada na playlist");
            }
            yield this.playlistDatabase.relateOneMusicToPlaylist(playlistId, musicId);
        });
    }
    removeMusicFromPlaylist(token, musicId, playlistId) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Faça novo login.");
            }
            if (user.getRole() === User_1.UserRole.ADMINISTRATOR || user.getRole() === User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para remover a música da playlist!");
            }
            const music = yield this.musicDatabase.getMusicById(musicId);
            if (!music) {
                throw new NotFoundError_1.NotFoundError("Música não encontrada!");
            }
            const playlist = yield this.playlistDatabase.getPlaylistById(playlistId);
            if (!playlist) {
                throw new NotFoundError_1.NotFoundError("Playlist não encontrada!");
            }
            if (playlist.getCollaborative() === false) {
                const myPlaylists = yield this.playlistDatabase.getPlaylistsByUserId(user.getId());
                const findPlaylist = myPlaylists.find(playlist => playlist.getId() === playlistId);
                if (!findPlaylist) {
                    throw new GenericError_1.GenericError("Você não pode deletar musica de uma playlist que não criou");
                }
            }
            yield this.playlistDatabase.removeMusicFromPlaylist(musicId, playlistId);
        });
    }
    deletePlaylist(token, playlistId) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Faça novo login.");
            }
            if (user.getRole() === User_1.UserRole.ADMINISTRATOR || user.getRole() === User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para deletar essa playlist!");
            }
            const playlist = yield this.playlistDatabase.getPlaylistById(playlistId);
            if (!playlist) {
                throw new NotFoundError_1.NotFoundError("Playlist não encontrada!");
            }
            if (playlist.getCollaborative() === false) {
                const myPlaylists = yield this.playlistDatabase.getPlaylistsByUserId(user.getId());
                const findPlaylist = myPlaylists.find(playlist => playlist.getId() === playlistId);
                if (!findPlaylist) {
                    throw new GenericError_1.GenericError("Você não pode deletar musica de uma playlist que não criou");
                }
            }
            yield this.playlistDatabase.deletePlaylist(playlistId);
        });
    }
    getPlaylistDetail(token, playlistId = "nope", page) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() === User_1.UserRole.ADMINISTRATOR || user.getRole() === User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para visualizar os detalhes da playlist!");
            }
            const offset = 10 * (page - 1);
            const playlistDetail = yield this.playlistDatabase.getPlaylistDetail(playlistId, offset);
            if (!playlistDetail) {
                throw new NotFoundError_1.NotFoundError("Playlist não encontrada!");
            }
            return playlistDetail;
        });
    }
    countPlaylistDetail(playlistId) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.playlistDatabase.countPlaylistDetail(playlistId);
            return result;
        });
    }
    makeCollaborative(token, playlistId, option) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.PAYINGLISTENER) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para tornar essa playlist colaborativa!");
            }
            const playlist = yield this.playlistDatabase.getPlaylistById(playlistId);
            if (!playlist) {
                throw new NotFoundError_1.NotFoundError("Playlist não encontrada!");
            }
            yield this.playlistDatabase.makeCollaborative(playlistId, option);
        });
    }
    editPlaylistName(token, playlistId, playlistName) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() === User_1.UserRole.ADMINISTRATOR || user.getRole() === User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para editar o nome dessa playlist!");
            }
            const playlist = yield this.playlistDatabase.getPlaylistById(playlistId);
            if (!playlist) {
                throw new NotFoundError_1.NotFoundError("Playlist não encontrada!");
            }
            if (user.getRole() !== User_1.UserRole.NONPAYINGLISTENER && playlist.getCollaborative() === false) {
                throw new GenericError_1.GenericError("Você não pode alterar o nome dessa playlist");
            }
            yield this.playlistDatabase.editPlaylistName(playlistId, playlistName);
        });
    }
}
exports.PlaylistBusiness = PlaylistBusiness;
