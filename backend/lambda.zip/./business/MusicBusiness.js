"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MusicBusiness = void 0;
const Music_1 = require("../model/Music");
const NotFoundError_1 = require("../errors/NotFoundError");
const GenericError_1 = require("../errors/GenericError");
const UnauthorizedError_1 = require("../errors/UnauthorizedError");
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
const User_1 = require("../model/User");
class MusicBusiness {
    constructor(musicDatabase, albumDatabase, userDatabase, idGenerator, authenticator) {
        this.musicDatabase = musicDatabase;
        this.albumDatabase = albumDatabase;
        this.userDatabase = userDatabase;
        this.idGenerator = idGenerator;
        this.authenticator = authenticator;
    }
    createMusic(token, name, albumId) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!name || !albumId || !token) {
                throw new InvalidParameterError_1.InvalidParameterError("Preencha os campos para prosseguir.");
            }
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Faça novo login");
            }
            if (user.getRole() !== User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para acessar esse endpoint.");
            }
            const foundAlbum = yield this.albumDatabase.getAlbumById(albumId);
            if (!foundAlbum) {
                throw new NotFoundError_1.NotFoundError("Álbum não encontrado");
            }
            const musicsInAlbum = yield this.musicDatabase.getMusicsByAlbumId(albumId);
            const foundName = musicsInAlbum.find(item => item.getName() === name);
            if (foundName) {
                throw new GenericError_1.GenericError("Uma música com esse nome já existe neste álbum");
            }
            const id = this.idGenerator.generatorId();
            const music = new Music_1.Music(id, name, albumId);
            yield this.musicDatabase.createMusic(music);
        });
    }
    getAllMusicsDetailed() {
        return __awaiter(this, void 0, void 0, function* () {
            const musics = yield this.musicDatabase.getAllMusicsDetailed();
            return musics;
        });
    }
    getMusicsByGenre(genreId = "nope", page) {
        return __awaiter(this, void 0, void 0, function* () {
            const offset = 10 * (page - 1);
            const musics = yield this.musicDatabase.getMusicsByGenre(genreId, offset);
            return musics;
        });
    }
    getMusicsList(page) {
        return __awaiter(this, void 0, void 0, function* () {
            const offset = 10 * (page - 1);
            const musics = yield this.musicDatabase.getMusicsList(offset);
            return musics;
        });
    }
    countMusicsByGenre(genreId) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.musicDatabase.countMusicsByGenre(genreId);
            return result;
        });
    }
    countMusicsList() {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.musicDatabase.countMusicsList();
            return result;
        });
    }
    getMyMusics(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Faça novo login.");
            }
            if (user.getRole() !== User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para acessar esse endpoint.");
            }
            const musics = yield this.musicDatabase.getMyMusics(userData.id);
            return musics;
        });
    }
    deleteMusic(token, id) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Faça novo login.");
            }
            if (user.getRole() !== User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para acessar esse endpoint.");
            }
            const music = yield this.musicDatabase.getMusicById(id);
            if ((music === null || music === void 0 ? void 0 : music.getId()) === undefined) {
                throw new NotFoundError_1.NotFoundError("Música não encontrada.");
            }
            yield this.musicDatabase.deleteMusic(id);
        });
    }
    editMusicName(token, musicId, musicName) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Faça novo login.");
            }
            if (user.getRole() !== User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para acessar esse endpoint.");
            }
            const music = yield this.musicDatabase.getMusicById(musicId);
            if ((music === null || music === void 0 ? void 0 : music.getId()) === undefined) {
                throw new NotFoundError_1.NotFoundError("Música não encontrada.");
            }
            yield this.musicDatabase.editMusicName(musicId, musicName);
        });
    }
    editAlbumToMusic(token, musicId, albumId) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Faça novo login.");
            }
            if (user.getRole() !== User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para acessar esse endpoint.");
            }
            const music = yield this.musicDatabase.getMusicById(musicId);
            if ((music === null || music === void 0 ? void 0 : music.getId()) === undefined) {
                throw new NotFoundError_1.NotFoundError("Música não encontrada.");
            }
            const album = yield this.albumDatabase.getAlbumById(albumId);
            if ((album === null || album === void 0 ? void 0 : album.getId()) === undefined) {
                throw new NotFoundError_1.NotFoundError("Álbum não encontrado.");
            }
            yield this.musicDatabase.editAlbumToMusic(musicId, albumId);
        });
    }
}
exports.MusicBusiness = MusicBusiness;
