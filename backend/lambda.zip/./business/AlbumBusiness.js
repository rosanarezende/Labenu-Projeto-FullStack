"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumBusiness = void 0;
const NotFoundError_1 = require("../errors/NotFoundError");
const UnauthorizedError_1 = require("../errors/UnauthorizedError");
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
const User_1 = require("../model/User");
const Album_1 = require("../model/Album");
class AlbumBusiness {
    constructor(albumDatabase, userDatabase, genreDatabase, idGenerator, authenticator) {
        this.albumDatabase = albumDatabase;
        this.userDatabase = userDatabase;
        this.genreDatabase = genreDatabase;
        this.idGenerator = idGenerator;
        this.authenticator = authenticator;
    }
    createAlbum(token, name, genreList) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!name || !genreList || !token) {
                throw new InvalidParameterError_1.InvalidParameterError("Preencha os campos para prosseguir.");
            }
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para cadastrar um álbum!");
            }
            const id = this.idGenerator.generatorId();
            const bandId = user.getId();
            const newAlbum = new Album_1.Album(id, bandId, name);
            const genres = yield this.genreDatabase.getAllGenres();
            for (const genre of genreList) {
                let found = genres.find(item => item.getId() === genre);
                if (!found) {
                    throw new NotFoundError_1.NotFoundError("Gênero não encontrado!");
                }
            }
            yield this.albumDatabase.createAlbum(newAlbum);
            yield this.albumDatabase.relateGenreAlbum(newAlbum.getId(), genreList);
        });
    }
    getAlbunsByBandId(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para buscar álbuns por artista!");
            }
            const albuns = yield this.albumDatabase.getAlbunsByBandId(user.getId());
            return albuns;
        });
    }
    deleteAlbum(token, albumId) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para deletar esse álbum!");
            }
            const album = yield this.albumDatabase.getAlbumById(albumId);
            if ((album === null || album === void 0 ? void 0 : album.getId()) === undefined) {
                throw new NotFoundError_1.NotFoundError("Álbum não encontrado.");
            }
            yield this.albumDatabase.deleteAlbum(albumId);
        });
    }
    editAlbumName(token, albumId, albumName) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para deletar esse álbum!");
            }
            const album = yield this.albumDatabase.getAlbumById(albumId);
            if ((album === null || album === void 0 ? void 0 : album.getId()) === undefined) {
                throw new NotFoundError_1.NotFoundError("Álbum não encontrado.");
            }
            yield this.albumDatabase.editAlbumName(albumId, albumName);
        });
    }
}
exports.AlbumBusiness = AlbumBusiness;
