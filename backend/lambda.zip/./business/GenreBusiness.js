"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenreBusiness = void 0;
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
const NotFoundError_1 = require("../errors/NotFoundError");
const UnauthorizedError_1 = require("../errors/UnauthorizedError");
const Genre_1 = require("../model/Genre");
const User_1 = require("../model/User");
const GenericError_1 = require("../errors/GenericError");
class GenreBusiness {
    constructor(genreDatabase, userDatabase, idGenerator, authenticator) {
        this.genreDatabase = genreDatabase;
        this.userDatabase = userDatabase;
        this.idGenerator = idGenerator;
        this.authenticator = authenticator;
    }
    addGenre(name, token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            if (user.getRole() !== User_1.UserRole.ADMINISTRATOR) {
                throw new UnauthorizedError_1.UnauthorizedError("Você não tem permissão para cadastrar um gênero!");
            }
            if (!name || !token) {
                throw new InvalidParameterError_1.InvalidParameterError("Preencha os campos para prosseguir.");
            }
            const genre = yield this.genreDatabase.getGenreByName(name);
            if (genre) {
                throw new GenericError_1.GenericError("Esse gênero já foi adicionado anteriormente.");
            }
            const id = this.idGenerator.generatorId();
            const newGenre = new Genre_1.Genre(id, name);
            yield this.genreDatabase.addGenre(newGenre);
        });
    }
    getAllGenres(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = this.authenticator.verify(token);
            const user = yield this.userDatabase.getUserById(userData.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário não encontrado. Realize novo login.");
            }
            const genres = yield this.genreDatabase.getAllGenres();
            return genres;
        });
    }
}
exports.GenreBusiness = GenreBusiness;
