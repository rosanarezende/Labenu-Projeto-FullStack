"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumController = void 0;
const AlbumBusiness_1 = require("../business/AlbumBusiness");
const UserDatabase_1 = require("../data/UserDatabase");
const AlbumDatabase_1 = require("../data/AlbumDatabase");
const IdGenerator_1 = require("../services/IdGenerator");
const Authenticator_1 = require("../services/Authenticator");
const GenreDatabase_1 = require("../data/GenreDatabase");
const BaseDatabase_1 = require("../data/BaseDatabase");
class AlbumController {
    createAlbum(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { name, genreList } = req.body;
            try {
                yield AlbumController.AlbumBusiness.createAlbum(token, name, genreList);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({ message: "Álbum criado com sucesso!" });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    getAlbunsByBandId(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            try {
                const albuns = yield AlbumController.AlbumBusiness.getAlbunsByBandId(token);
                // await BaseDatabase.destroyConnection()
                res.status(200).send(albuns);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    deleteAlbum(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { id } = req.params;
            try {
                yield AlbumController.AlbumBusiness.deleteAlbum(token, id);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({
                    message: "Álbum deletado com sucesso!"
                });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    editAlbumName(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { albumId, albumName } = req.body;
            try {
                yield AlbumController.AlbumBusiness.editAlbumName(token, albumId, albumName);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({
                    message: "Álbum editado com sucesso!"
                });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
}
exports.AlbumController = AlbumController;
AlbumController.AlbumBusiness = new AlbumBusiness_1.AlbumBusiness(new AlbumDatabase_1.AlbumDatabase(), new UserDatabase_1.UserDatabase(), new GenreDatabase_1.GenreDatabase(), new IdGenerator_1.IdGenerator(), new Authenticator_1.Authenticator());
