"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MusicController = void 0;
const MusicBusiness_1 = require("../business/MusicBusiness");
const MusicDatabase_1 = require("../data/MusicDatabase");
const AlbumDatabase_1 = require("../data/AlbumDatabase");
const UserDatabase_1 = require("../data/UserDatabase");
const IdGenerator_1 = require("../services/IdGenerator");
const Authenticator_1 = require("../services/Authenticator");
const BaseDatabase_1 = require("../data/BaseDatabase");
class MusicController {
    createMusic(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { name, albumId } = req.body;
            try {
                yield MusicController.MusicBusiness.createMusic(token, name, albumId);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({ message: "Música criada com sucesso!" });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    getAllMusicsDetailed(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const musics = yield MusicController.MusicBusiness.getAllMusicsDetailed();
                // await BaseDatabase.destroyConnection()
                res.status(200).send(musics);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    getMusicsByGenre(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { genreId } = req.params;
            let page = Number(req.params.page) >= 1 ? Number(req.params.page) : 1;
            try {
                const musics = yield MusicController.MusicBusiness.getMusicsByGenre(genreId, page);
                // await BaseDatabase.destroyConnection()
                res.status(200).send(musics);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    getMusicsList(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { page } = req.params;
            try {
                const musics = yield MusicController.MusicBusiness.getMusicsList(Number(page));
                // await BaseDatabase.destroyConnection()
                res.status(200).send(musics);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    countMusicsByGenre(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { id } = req.params;
            try {
                const result = yield MusicController.MusicBusiness.countMusicsByGenre(id);
                // await BaseDatabase.destroyConnection()
                res.status(200).send(result);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    countMusicsList(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield MusicController.MusicBusiness.countMusicsList();
                // await BaseDatabase.destroyConnection()
                res.status(200).send(result);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    getMyMusics(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            try {
                const musics = yield MusicController.MusicBusiness.getMyMusics(token);
                // await BaseDatabase.destroyConnection()
                res.status(200).send(musics);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    deleteMusic(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { id } = req.params;
            try {
                yield MusicController.MusicBusiness.deleteMusic(token, id);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({
                    message: "Música deletada com sucesso!"
                });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    editMusicName(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { musicId, musicName } = req.body;
            try {
                yield MusicController.MusicBusiness.editMusicName(token, musicId, musicName);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({
                    message: "Música editada com sucesso!"
                });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    editAlbumToMusic(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { musicId, albumId } = req.body;
            try {
                yield MusicController.MusicBusiness.editAlbumToMusic(token, musicId, albumId);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({
                    message: "Música relacionada ao novo álbum com sucesso!"
                });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
}
exports.MusicController = MusicController;
MusicController.MusicBusiness = new MusicBusiness_1.MusicBusiness(new MusicDatabase_1.MusicDatabase(), new AlbumDatabase_1.AlbumDatabase(), new UserDatabase_1.UserDatabase(), new IdGenerator_1.IdGenerator(), new Authenticator_1.Authenticator());
