"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const UserBusiness_1 = require("../business/UserBusiness");
const UserDatabase_1 = require("../data/UserDatabase");
const HashManager_1 = require("../services/HashManager");
const Authenticator_1 = require("../services/Authenticator");
const IdGenerator_1 = require("../services/IdGenerator");
const BaseDatabase_1 = require("../data/BaseDatabase");
class UserController {
    signupListeningUser(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { name, email, nickname, password, role } = req.body;
            try {
                const result = yield UserController.UserBusiness.signupListeningUser(name, email, nickname, password, role);
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(200).send(result);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    signupAdministratorUser(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { name, email, nickname, password } = req.body;
            try {
                const result = yield UserController.UserBusiness.signupAdministratorUser(name, email, nickname, password, token);
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(200).send(result);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    signupBandUser(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { name, email, nickname, password, description } = req.body;
            try {
                yield UserController.UserBusiness.signupBandUser(name, email, nickname, password, description);
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(200).send({
                    message: "Artista cadastrado. Aguarde aprovação de um administrador para acessar a aplicação!"
                });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    login(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { input, password } = req.body;
            try {
                const result = yield UserController.UserBusiness.login(input, password);
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(200).send(result);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    getAllBands(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            try {
                const bands = yield UserController.UserBusiness.getAllBands(token);
                // await BaseDatabase.destroyConnection()
                res.status(200).send(bands);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    aproveBand(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { id } = req.body;
            try {
                yield UserController.UserBusiness.aproveBand(id, token);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({
                    message: "Artista aprovado com sucesso!"
                });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    getAllUsers(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            try {
                const users = yield UserController.UserBusiness.getAllUsers(token);
                // await BaseDatabase.destroyConnection()
                res.status(200).send(users);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    blockUser(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { id } = req.body;
            try {
                yield UserController.UserBusiness.blockUser(id, token);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({
                    message: "Usuário bloqueado com sucesso!"
                });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    getProfile(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            try {
                const user = yield UserController.UserBusiness.getProfile(token);
                // await BaseDatabase.destroyConnection()
                res.status(200).send(user);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    changeNameById(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { name } = req.body;
            try {
                yield UserController.UserBusiness.changeNameById(name, token);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({
                    message: "Nome do usuário alterado com sucesso!"
                });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    makePremium(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { id } = req.body;
            try {
                yield UserController.UserBusiness.makePremium(id, token);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({
                    message: "Usuário trasnformado em PREMIUM com sucesso!"
                });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
}
exports.UserController = UserController;
UserController.UserBusiness = new UserBusiness_1.UserBusiness(new UserDatabase_1.UserDatabase(), new HashManager_1.HashManager(), new Authenticator_1.Authenticator(), new IdGenerator_1.IdGenerator());
