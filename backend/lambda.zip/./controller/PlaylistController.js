"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlaylistController = void 0;
const PlaylistBusiness_1 = require("../business/PlaylistBusiness");
const UserDatabase_1 = require("../data/UserDatabase");
const IdGenerator_1 = require("../services/IdGenerator");
const Authenticator_1 = require("../services/Authenticator");
const BaseDatabase_1 = require("../data/BaseDatabase");
const PlaylistDatabase_1 = require("../data/PlaylistDatabase");
const MusicDatabase_1 = require("../data/MusicDatabase");
class PlaylistController {
    createPlaylist(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { name } = req.body;
            try {
                yield PlaylistController.PlaylistBusiness.createPlaylist(token, name);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({ message: "Playlist criada com sucesso!" });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    getPlaylistsByUserId(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            try {
                const result = yield PlaylistController.PlaylistBusiness.getPlaylistsByUserId(token);
                // await BaseDatabase.destroyConnection()
                res.status(200).send(result);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    addMusicToPlaylist(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { playlistId, musicId } = req.body;
            try {
                yield PlaylistController.PlaylistBusiness.addMusicToPlaylist(token, musicId, playlistId);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({ message: "Música adicionada a playlist com sucesso!" });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    removeMusicFromPlaylist(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { playlistId, musicId } = req.body;
            try {
                yield PlaylistController.PlaylistBusiness.removeMusicFromPlaylist(token, musicId, playlistId);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({ message: "Música removida da playlist com sucesso!" });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    deletePlaylist(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { id } = req.params;
            try {
                yield PlaylistController.PlaylistBusiness.deletePlaylist(token, id);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({ message: "Playlist deletada com sucesso!" });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    getPlaylistDetail(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { id, page } = req.params;
            console.log(req.headers);
            try {
                const result = yield PlaylistController.PlaylistBusiness.getPlaylistDetail(token, id, Number(page));
                // await BaseDatabase.destroyConnection()
                res.status(200).send(result);
            }
            catch (err) {
                console.log(err);
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    countPlaylistDetail(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { id } = req.params;
            try {
                const result = yield PlaylistController.PlaylistBusiness.countPlaylistDetail(id);
                // await BaseDatabase.destroyConnection()
                res.status(200).send(result);
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    makeCollaborative(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { playlistId, option } = req.body;
            try {
                yield PlaylistController.PlaylistBusiness.makeCollaborative(token, playlistId, option);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({ message: "Opção de colaboração alterada com sucesso!" });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    editPlaylistName(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const token = req.headers.authorization || req.headers.Authorization;
            const { playlistId, playlistName } = req.body;
            try {
                yield PlaylistController.PlaylistBusiness.editPlaylistName(token, playlistId, playlistName);
                // await BaseDatabase.destroyConnection()
                res.status(200).send({ message: "Nome da playlist alterado com sucesso!" });
            }
            catch (err) {
                yield BaseDatabase_1.BaseDatabase.destroyConnection();
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
}
exports.PlaylistController = PlaylistController;
PlaylistController.PlaylistBusiness = new PlaylistBusiness_1.PlaylistBusiness(new PlaylistDatabase_1.PlaylistDatabase(), new UserDatabase_1.UserDatabase(), new MusicDatabase_1.MusicDatabase(), new IdGenerator_1.IdGenerator(), new Authenticator_1.Authenticator());
